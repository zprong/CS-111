// Name: Zachary Prong, Michael Gee
// Email: prongzachary@gmail.com, mikedodger10@gmail.com
// ID: 304 958 784, 004 800 083

#define _GNU_SOURCE
#include <stdio.h>	// printf, exit
#include <stdlib.h> 	// fprintf
#include <unistd.h>	// pread
#include <sys/types.h>	// open
#include <sys/stat.h>	// open
#include <fcntl.h>	// open
#include <string.h>	// strerror
#include <errno.h>	// errno
#include <math.h>	// pow
#include <time.h> 	// time_t, strftime
#include <stdint.h>
#include "ext2.h"

// Global Variables
const char* fileName;
int fd = -1;
__u32 blockSize;

void print_error(char* error) {
	fprintf(stderr, "Error: %s - %s\n", error, strerror(errno));
	exit(1);
}


void indirect_reference_summary(unsigned int inodeNum, unsigned int blockOffset, unsigned int indirection, __u32 blockNum) {
	uint32_t* refNum = malloc(sizeof(uint32_t));
	if (refNum == NULL)
		print_error("malloc() failed in indirect_reference_summary");

	int offset = blockNum*blockSize;

	for (__u32 i = 0; i < blockSize/sizeof(uint32_t); i++) {
		if (pread(fd, refNum, sizeof(uint32_t), offset + i*sizeof(uint32_t)) == -1)
			print_error("pread() failed in indirect_reference_summary");

		if (*refNum != 0) {
			unsigned int currOffset = blockOffset+(unsigned int)(i*pow(256, indirection-1));
			printf("INDIRECT,%d,%d,%d,%d,%d\n",
				inodeNum, indirection, currOffset,
				blockNum, *refNum);
			if (indirection > 1)
				indirect_reference_summary(inodeNum, currOffset, indirection-1, *refNum);
		}
	}

	free(refNum);
	return;
}

unsigned int directory_entry_summary(unsigned int inodeNum, unsigned int byteOffset, __u32 blockNum) {
	struct ext2_dir_entry* dirEntry = malloc(sizeof(struct ext2_dir_entry));
	unsigned int byteNum = blockNum * blockSize;

	while (byteNum < (blockNum+1)*blockSize) {
		if (pread(fd, dirEntry, sizeof(struct ext2_dir_entry), byteNum) == -1)
			print_error("pread() failed in directory_entry_summary");

		if (dirEntry->inode != 0)
			printf("DIRENT,%d,%d,%d,%d,%d,\'%s\'\n",
				inodeNum, byteOffset, dirEntry->inode,
				dirEntry->rec_len, dirEntry->name_len, dirEntry->name);

		byteNum += dirEntry->rec_len;
		byteOffset += dirEntry->rec_len;
	}
	return byteOffset;
}

unsigned int indirect_directory_entry_summary(unsigned int inodeNum, unsigned int byteOffset, unsigned int indirection, __u32 blockNum) {
	uint32_t* referenceNumber = malloc(sizeof(uint32_t));
	if (referenceNumber == NULL)
		print_error("malloc() failed in indirect_directory_entry_summary");
	int offset = blockNum * blockSize;

	for (unsigned int i = 0; i < blockSize/sizeof(uint32_t); i++) {
		if (pread(fd, referenceNumber, sizeof(uint32_t), offset + i*sizeof(uint32_t)) == -1)
			print_error("pread() failed in indirect_directory_entry_summary");

		if (indirection > 0) {
			if (*referenceNumber != 0) {
				unsigned int nextOffset = directory_entry_summary(inodeNum, byteOffset, *referenceNumber);
				byteOffset = nextOffset;
			}
		}
		else {
			if (*referenceNumber != 0) {
				unsigned int nextOffset = indirect_directory_entry_summary(inodeNum, byteOffset, indirection - 1, *referenceNumber);
				byteOffset = nextOffset;
			}
		}
	}

	free(referenceNumber);
	return byteOffset;
}

void directory_entries_handler(unsigned int inodeNum, struct ext2_inode inode) {
	unsigned int byteOffset = 0;
	for (int i = 0; i < 12; i++) {
		if (inode.i_block[i] != 0) {
			unsigned int nextOffset = directory_entry_summary(inodeNum, byteOffset, inode.i_block[i]);
			byteOffset = nextOffset;
		}
	}

	for (int i = 12; i < 15; i++) {
		if (inode.i_block[i] != 0) {
			unsigned int nextOffset = indirect_directory_entry_summary(inodeNum, byteOffset, i-11, inode.i_block[i]);
			byteOffset = nextOffset;
		}
	}
	return;
}

void analyze_inodes(__u32 inodesTable, __u32 totalInodes, __u32 inodeSize) {
	struct ext2_inode* inode = malloc(inodeSize);
	if (inode == NULL)
		print_error("malloc() failed in analyze_inodes");

	int offset = blockSize * inodesTable;

	// Go through all inodes in a group
	for (__u32 i = 0; i < totalInodes; i++) {
		if (pread(fd, inode, inodeSize, offset + inodeSize*i) == -1)
			print_error("pread() failed in analyze_inodes");

		if (inode->i_mode == 0 || inode->i_links_count == 0)
			continue;

		char fileType;

		// Directory
		if (inode->i_mode & 0x4000) {
			fileType = 'd';
			directory_entries_handler(i+1, *inode);
			indirect_reference_summary(i+1, 12, 1, inode->i_block[12]);
			indirect_reference_summary(i+1, 268, 2, inode->i_block[13]);
			indirect_reference_summary(i+1, 65804, 3, inode->i_block[14]);
		}

		// File
		else if (inode->i_mode & 0x8000) {
			fileType = 'f';
			indirect_reference_summary(i+1, 12, 1, inode->i_block[12]);
			indirect_reference_summary(i+1, 268, 2, inode->i_block[13]);
			indirect_reference_summary(i+1, 65804, 3, inode->i_block[14]);
		}

		// Symbolic Link
		else if (inode->i_mode & 0xA000)
			fileType = 's';

		else
			fileType = '?';

		uint16_t owner = inode->i_uid;
		uint16_t group = inode->i_gid;
		uint16_t linkCount = inode->i_links_count;

		time_t time;

		char created[18];
		time = inode->i_ctime;
		struct tm* ctime = gmtime(&time);
		strftime(created, 18, "%D %H:%M:%S", ctime);

		char modified[18];
		time = inode->i_mtime;
		struct tm* mtime = gmtime(&time);
		strftime(modified, 18, "%D %H:%M:%S", mtime);

		char accessed[18];
		time = inode->i_atime;
		struct tm* atime = gmtime(&time);
		strftime(accessed, 18, "%D %H:%M:%S", atime);

		__u32 size = inode->i_size;
		__u32 blocks = inode->i_blocks;

		printf("INODE,%u,%c,%o,%u,%u,%u,%s,%s,%s,%d,%d",
			i+1, fileType, inode->i_mode & 0xFFF,
			owner, group, linkCount,
			created, modified, accessed,
			size, blocks);

		for (int j = 0; j < 15; j++)
			printf(",%d", inode->i_block[j]);

		printf("\n");
	}

	free(inode);
	return;
}

void analyze_group_descriptor (__u32 totalBlocks, __u32 totalInodes, __u32 inodeSize) {
	struct ext2_group_desc* groupDesc = malloc(sizeof(struct ext2_group_desc));
	if (groupDesc == NULL)
		print_error("malloc() failed in group descriptor");

	if (pread(fd, groupDesc, sizeof(struct ext2_group_desc), 2*1024) == -1)
		print_error("pread() failed in group summary");

	uint16_t numFreeBlocks = groupDesc->bg_free_blocks_count;
	uint16_t numFreeInodes = groupDesc->bg_free_inodes_count;
	__u32 blockBitmap = groupDesc->bg_block_bitmap;
	__u32 inodeBitmap = groupDesc->bg_inode_bitmap;
	__u32 firstBlockInodes = groupDesc->bg_inode_table;

	printf("GROUP,0,%u,%u,%u,%u,%u,%u,%u\n",
			totalBlocks, totalInodes, numFreeBlocks,
			numFreeInodes, blockBitmap, inodeBitmap,
			firstBlockInodes);

	// Scan for free blocks
	unsigned char* blocks = malloc(totalBlocks);
	int blockOffset = blockBitmap * blockSize;

	if (blocks == NULL)
		print_error("malloc() failed in scan_free_blocks");

	if (pread(fd, blocks, totalBlocks, blockOffset) == -1)
		print_error("pread() failed in scan_free_blocks");

	for (unsigned int i = 0; i < totalBlocks; i++) {
		char c = blocks[i];

		// Iterate through the byte
		for (unsigned int j = 0; j < 8; j++) {
			// if ((byte & (1<<j)) == 0)
			if ((c & 1) == 0)
				printf("BFREE,%u\n", i*8+j+1);
			c = c >> 1;
		}
	}
	free(blocks);

	// Scan for free inodes
	unsigned char* inodes = malloc(totalInodes);
	int inodeOffset = inodeBitmap * blockSize;

	if (inodes == NULL)
		print_error("malloc() failed in scan_free_inodes");

	if (pread(fd, inodes, totalInodes, inodeOffset) == -1)
		print_error("pread() failed in scan_free_inodes");

	for (unsigned int i = 0; i < totalInodes; i++) {
		char c = inodes[i];
		for (unsigned int j = 0; j < 8; j++)
			if ( !(c & (1 << j)) )
				printf("IFREE,%u\n", i*8+j+1);
	}
	free(inodes);

	// Call analyze_inodes()
	analyze_inodes(firstBlockInodes, totalInodes, inodeSize);

	free(groupDesc);
	return;
}

void analyze_superblock() {
	struct ext2_super_block* superblock = malloc(1024);
	if (superblock == NULL)
		print_error("malloc() failed in superblock");

	if (pread(fd, superblock, 1024, 1024) == -1)
		print_error("pread() failed in superblock summary");

	__u32 totalBlocks = superblock->s_blocks_count;
	__u32 totalInodes = superblock->s_inodes_count;
	blockSize = 1024 << superblock->s_log_block_size;
	__u32 inodeSize = superblock->s_inode_size;
	__u32 blocksPerG = superblock->s_blocks_per_group;
	__u32 inodesPerG = superblock->s_inodes_per_group;
	__u32 firstNonreservedInode = superblock->s_first_ino;

	printf("SUPERBLOCK,%u,%u,%u,%u,%u,%u,%u\n",
			totalBlocks, totalInodes, blockSize,
			inodeSize, blocksPerG, inodesPerG,
			firstNonreservedInode);

	free(superblock);
	analyze_group_descriptor(totalBlocks, totalInodes, inodeSize);

	return;
}

int main(int argc, char* argv[]) {
	if (argc != 2)
		print_error("./lab3a <image name>");
	fileName = argv[1];

	fd = open(fileName, O_RDONLY);
	if (fd == -1)
		print_error("failed to open image");

	analyze_superblock();

	close(fd);

	exit(0);
}
