// Name: Zachary Prong
// Email: prongzachary@gmail.com
// ID: 304 958 784

#include <stdio.h>    // fprintf
#include <stdlib.h>   // fopen
#include <sys/time.h> // timeval,tm,gettimeofday,localtime
#include <unistd.h>   // getopt_long
#include <getopt.h>   // getopt_ong
#include <errno.h>    // errno
#include <string.h>   // strerror
#include <mraa.h>     // mraa
#include <math.h>     // log
#include <string.h>   // strlen
#include <poll.h>     // poll

// GLOBAL VARIABLES
int period = 1; // default period = 1/second
char scale = 'F'; // default scale = fahrenheit
int enabled = 1;
int is_shutdown = 0;
FILE* logfile = NULL;

mraa_aio_context tempSensor;
mraa_gpio_context btn;

// === print_error() ==========================================
void print_error(char* error) {
	fprintf(stderr, "Error: %s - %s\n", error, strerror(errno));
	exit(1);
}

// === exec_command() ==========================================
void exec_command(char* comm) {
	if (!strncmp(comm, "SCALE=", 6*sizeof(char))) {
		if (comm[6] == 'F')
			scale = 'F';
		else if (comm[6] == 'C')
			scale = 'C';
		else
			print_error("invalid letter for scale");
	}
	else if (!strncmp(comm, "PERIOD=", 7*sizeof(char)))
        	period = atoi(comm+7);
	else if (!strcmp(comm, "STOP"))
    		enabled = 0;
	else if (!strcmp(comm, "START"))
	        enabled = 1;
	else if (!strcmp(comm, "OFF"))
	    	is_shutdown = 1;
	else if (strncmp(comm, "LOG", 3*sizeof(char)) != 0)
    		print_error(comm);

	if (logfile != NULL)
    		fprintf(logfile, "%s\n", comm);
}

// === readTemp() ==============================================
float readTemp(char scale) {
	int measurement = mraa_aio_read(tempSensor);
	int B = 4275; // B value of the thermistor
	float R0 = 100000.0; // R0 = 100k
	float R = 1023.0/((float)measurement) - 1.0;
	R *= R0;

	// Convert to celsius
	float temp = 1.0/(log(R/R0)/B + 1/298.15) - 273.15;
	if (scale == 'F')
		temp = (temp*9.0)/5.0 + 32;
	return temp;
}

// === shutdown() ========================================
void shutdown() {
	is_shutdown = 1;
}

// === main() ==================================================
int main (int argc, char* argv[]) {
	int option_index;
	int c;

	static struct option long_options[] = {
    	  {"period",    required_argument, 0, 'p'},
    	  {"scale",     required_argument, 0, 's'},
	  {"log",       required_argument, 0, 'l'}
	};

	while(1) {
		option_index = 0;
		c = getopt_long(argc, argv, "p:s:l:", long_options, &option_index);
	    	if (c == -1)
		      	break;
		switch(c) {
		  case 'p':
			period = atoi(optarg);
			if (period < 1)
				print_error("./lab4b --period must be at least 1");
			break;
		  case 's':
			if ((strlen(optarg) != 1) || (*optarg != 'F' && *optarg != 'C'))
				print_error("./lab4b --period must be 'F' or 'C'");
			scale = *optarg;
			break;
		  case 'l':
			logfile = fopen(optarg, "a");
			if (logfile == NULL)
				print_error("failed to open specified file");
			break;
		  case '?':
			fprintf(stderr, "Error: Unrecognized argument\n");
			fprintf(stderr, "Usage: ./lab4b [--period=#] [--scale=#] [--log=filename]");
			exit(1);
		  default:
			printf("?? getopt returned character code 0%o ??\n", c);
		}
	}

	// Time
	struct timeval clock;
	struct tm* now;
	time_t nextDue = 0;

	// Initialize Temperature & Button
	tempSensor = mraa_aio_init(1);
	if (tempSensor == NULL) {
		fprintf(stderr, "Error: Failed to initialize AIO\n");
		mraa_deinit();
		exit(1);
	}
	btn = mraa_gpio_init(60);
	if (btn == NULL) {
		fprintf(stderr, "Error: Failed to initialize GPIO\n");
		mraa_deinit();
		exit(1);
	}
	mraa_gpio_isr(btn, MRAA_GPIO_EDGE_RISING, &shutdown, NULL);

	// I/O Strings
	char input[256];
	char command[256]; // parsed command from input
	char outbuf[256];  // prints to stdout and optionally the logfile

	memset(input,   0, 256);
	memset(command, 0, 256);
	memset(outbuf,  0, 256);

	// Poll
	struct pollfd pollStdin = {0, POLLIN, 0};

	while(!is_shutdown) {
		// See what time it is
		gettimeofday(&clock, 0);

		// See if it's time to generate reading
		if (enabled && clock.tv_sec >= nextDue) {
			// Get temperature
			float temp = readTemp(scale);
			int t = temp*10;

			// Report time and temperature
			now = localtime(&(clock.tv_sec));
			sprintf(outbuf, "%02d:%02d:%02d %d.%1d\n",
				now->tm_hour, now->tm_min, now->tm_sec,
				t/10, t%10);
			fputs(outbuf, stdout);
			if (logfile != NULL)
				fputs(outbuf, logfile);

			// Schedule next report
			nextDue = clock.tv_sec + period;
		}

		// See if we've received a command
		pollStdin.revents = 0;
		int offset = 0;
		int ret = poll(&pollStdin, 1, 0);
		if (ret >= 1) {
			if (pollStdin.revents & POLLIN) {
				int bytesRead = read(STDIN_FILENO,input,256);
				if (bytesRead == -1)
					print_error("failed to read input");
				for(int i = 0; i < bytesRead && offset < 256; i++) {
					if (input[i] =='\n') { // Finished parsing a command
						exec_command(command);
						offset = 0;
						memset(command, 0, 256);
					}
					else {
						command[offset] = input[i];
						offset++;
					}
				}
			}
		}
	}

	// Report shutdown time
	now = localtime(&(clock.tv_sec));
     	sprintf(outbuf, "%02d:%02d:%02d SHUTDOWN\n", \
          now->tm_hour, now->tm_min, now->tm_sec);
        fputs(outbuf, stdout);
        if (logfile != NULL)
          	fputs(outbuf, logfile);

	// Close
	mraa_aio_close(tempSensor);
	mraa_gpio_close(btn);
	exit(0);
}
