# Name: Zachary Prong, Michael Gee
# Email: prongzachary@gmail.com, mikedodger10@gmail.com
# ID: 304 958 784, 004 800 083

import sys,string,csv

status = 0;

class Superblock:
    def __init__(self,row):
        self.totalBlocks = int(row[1])
        self.totalInodes = int(row[2])
        self.firstNonReservedI = int(row[7])

class Inode:
    def __init__(self,row):
        self.inodeNum = int(row[1])
        self.fileStyle = row[2]
        self.linkCount = int(row[6])
        self.blocks = [int(row[i]) for i in range(12,24)]
        self.indirects = [int(row[i]) for i in range(24,27)]

class Dirent:
    def __init__(self,row):
        self.parInodeNum = int(row[1])
        self.inode = int(row[3])
        self.name = row[6]

class Indirect:
    def __init__(self,row):
        self.ownerInodeNum = int(row[1])
        self.indirectionLevel = int(row[2])
        self.blockOffset = int(row[3])
        self.refBlockNum = int(row[5])

##################################################3

def block_consistency_audit(superblock, group, freeBlocks, inodes, indirects):

    usedBlocks = []
    
    for inode in inodes:
        offset = 0
        
        # Direct Blocks
        for block in inode.blocks:
            #if int(block) != 0:
            if int(block) >= superblock.totalBlocks or int(block) < 0:
                print("INVALID BLOCK {} IN INODE {} AT OFFSET {}".format(block, inode.inodeNum, offset))
                status = 2
            elif int(block) < 8 and int(block) > 0:
                status = 2
                print("RESERVED BLOCK {} IN INODE {} AT OFFSET {}".format(block, inode.inodeNum, offset))
            elif int(block) > 0: 
                usedBlocks.append(int(block)) 
            offset += 1

        # Indirect Blocks
        # Single Indirect
        newBlock = inode.indirects[0]
        if int(newBlock) >= superblock.totalBlocks or int(newBlock) < 0:
            status = 2
            print("INVALID INDIRECT BLOCK {} IN INODE {} AT OFFSET 12".format(newBlock, inode.inodeNum))
        elif int(newBlock) < 8 and int(newBlock) > 0:
            print("RESERVED INDIRECT BLOCK {} IN INODE {} AT OFFSET 12".format(newBlock, inode.inodeNum))
            status = 2
        elif int(newBlock) > 0:
            usedBlocks.append(int(newBlock)) 

        # Double Indirect
        newBlock = inode.indirects[1]
        if int(newBlock) >= superblock.totalBlocks or int(newBlock) < 0:
            print("INVALID DOUBLE INDIRECT BLOCK {} IN INODE {} AT OFFSET 268".format(newBlock, inode.inodeNum))
            status = 2
        elif int(newBlock) < 8 and int(newBlock) > 0:
            print("RESERVED DOUBLE INDIRECT BLOCK {} IN INODE {} AT OFFSET 268".format(newBlock, inode.inodeNum))
            status = 2
        elif int(newBlock) > 0:
            usedBlocks.append(int(newBlock))

        # Triple Indirect
        newBlock = inode.indirects[2]
        if int(newBlock) >= superblock.totalBlocks or int(newBlock) < 0:
            print("INVALID TRIPLE INDIRECT BLOCK {} IN INODE {} AT OFFSET 65804".format(newBlock, inode.inodeNum))
            status = 2
        elif int(newBlock) < 8 and int(newBlock) > 0:
            print("RESERVED TRIPLE INDIRECT BLOCK {} IN INODE {} AT OFFSET 65804".format(newBlock, inode.inodeNum))
            status = 2
        elif newBlock > 0:
            usedBlocks.append(int(newBlock))

    # Invalid/Reserved Block Check
    for indirect in indirects:
        blockType = None
        if indirect.indirectionLevel == 1:
            blockType = "BLOCK"
        if indirect.indirectionLevel == 2:
            blockType = "INDIRECT BLOCK"
        if indirect.indirectionLevel == 3:
            blockType = "DOUBLE INDIRECT BLOCK"
        #else:
        #    print("Error: invalid level of indirection", file = sys.stderr)
        #    sys.exit(1)
        newBlock = indirect.refBlockNum
        if int(newBlock) >= superblock.totalBlocks or int(newBlock) < 0:
            print("INVALID {} {} IN INODE {} AT OFFSET {}".format(blockType, block, indirect.ownerInodeNum, indirect.blockOffset))
            status = 2
        elif int(newBlock) < 8:
            print("RESERVED {} {} IN INODE {} AT OFFSET {}".format(blockType, block, indirect.ownerInodeNum, indirect.blockOffset))
            status = 2
        elif int(newBlock) > 0:
            usedBlocks.append(newBlock)

    for block in range(8, superblock.totalBlocks):
        if block not in freeBlocks and block not in usedBlocks:
            print("UNREFERENCED BLOCK {}".format(block))
            status = 2
        elif block in freeBlocks and block in usedBlocks: 
            print("ALLOCATED BLOCK {} ON FREELIST".format(block))
            status = 2

    # Duplicate blocks
    okBlocks = dict()
    for i in range(8, superblock.totalBlocks):
        okBlocks[i] = 0
    blockType = {}
    blockType[1] = " "
    blockType[2] = "INDIRECT"
    blockType[3] = "DOUBLE INDIRECT"

    # Check for Duplicates
    dupBlocks = []
    for inode in inodes:
        for block in inode.blocks:
            if int(block) in okBlocks:
                okBlocks[int(block)] += 1
                if okBlocks[int(block)] > 1:
                    if block not in dupBlocks and block not in freeBlocks:
                        dupBlocks.append(block)
        for block in inode.indirects:
            if int(block) in okBlocks:
                okBlocks[int(block)] += 1
                if okBlocks[int(block)] > 1:
                    if block not in dupBlocks and block not in freeBlocks:
                        dupBlocks.append(block)

    for indirect in indirects:
        if int(indirect.refBlockNum) in okBlocks:
            okBlocks[int(indirect.refBlockNum)] += 1
            if okBlocks[int(indirect.refBlockNum)] > 1:
                if indirect.refBlockNum not in dupBlocks and indirect.refBlockNum not in freeBlocks:
                    dupBlocks.append(indirent.refBlockNum)

    dupBlocks = [x for x in dupBlocks if x != "0"]

    # Print Duplicates
    for dupBlock in dupBlocks:
        for inode in inodes:
            offset = 0
            for block in inode.blocks:
                if dupBlock == block:
                    print("DUPLICATE BLOCK {} IN INODE {} AT OFFSET {}".format(dupBlock, inode.inodeNum, offset))
                offset += 1
            if dupBlock == inode.indirects[0]:
                print("DUPLICATE INDIRECT BLOCK {} IN INODE {} AT OFFSET 12".format(dupBlock, inode.inodeNum))
            if dupBlock == inode.indirects[1]:
                print("DUPLICATE DOUBLE INDIRECT BLOCK {} IN INODE {} AT OFFSET 268".format(dupBlock, inode.inodeNum))
            if dupBlock == inode.indirects[2]:
                print("DUPLICATE TRIPLE INDIRECT BLOCK {} IN INODE {} AT OFFSET 65804".format(dupBlock, inode.inodeNum))
        for indirect in indirects:
            if dupBlock == indirect.refBlockNum:
                print("DUPLICATE {} BLOCK {} IN INODE {} AT OFFSET {}".format(blockType[int(indirect.indirectionLevel)], dupBlock, indirect.ownerInodeNum, indirect.blockOffset))
    
    

########################################################
#                                                      #
########################################################                
def inode_allocation_audit(superblock, freeInodes, inodes):
    maxInodeNum = superblock.totalInodes
    allocatedInodes = {inode.inodeNum for inode in inodes}
    firstNonReservedI = superblock.firstNonReservedI
    for inode in allocatedInodes: 
        if inode in freeInodes: 
            print("ALLOCATED INODE {} ON FREELIST".format(inode))
            status = 2

    for i in range(firstNonReservedI, maxInodeNum):
        if i not in freeInodes and i not in allocatedInodes:
            print("UNALLOCATED INODE {} NOT ON FREELIST".format(i))
            status = 2
    
    return allocatedInodes

########################################################
#                                                      #
########################################################
def directory_consistency_audit(superblock, inodes, dirents, inodeRefs, inodeStorage, allocatedInodes, freeInodes):
    maxInodeNum = superblock.totalInodes

    # link count consistency check 
    for inode in inodes:
        linkCount = inode.linkCount
        discoveredLinks  = inodeRefs[int(inode.inodeNum)]
        if discoveredLinks != linkCount:
            print("INODE {} HAS {} LINKS BUT LINKCOUNT IS {}".format(inode.inodeNum, discoveredLinks, linkCount))
            status = 2
            
    # invalid/unallocated directory check
    for dirent in dirents:
        if dirent.inode > maxInodeNum or dirent.inode < 1:
            print("DIRECTORY INODE {} NAME {} INVALID INODE {}".format(dirent.parInodeNum, dirent.name, dirent.inode))
            status = 2
        if dirent.inode not in allocatedInodes and dirent.inode in freeInodes:
            print("DIRECTORY INODE {} NAME {} UNALLOCATED INODE {}".format(dirent.parInodeNum, dirent.name, dirent.inode))
            status = 2

    # Check for current and parent
    parent = dict() # {}
    parent[2] = 2
    for dirent in dirents:
        if dirent.name != "'.'" and dirent.name != "'..'" and int(dirent.inode) not in parent:
            parent[int(dirent.inode)] = int(dirent.parInodeNum)
            

    for dirent in dirents:
        if dirent.name == "'.'" and dirent.parInodeNum != dirent.inode:
            print("DIRECTORY INODE {} NAME {} LINK TO INODE {} SHOULD BE {}".format(dirent.parInodeNum, dirent.name, dirent.inode, dirent.parInodeNum))
            status = 2
        if dirent.name == "'..'": # and parent[dirent.parInodeNum] != dirent.inode:
            theParent = parent[int(dirent.parInodeNum)]
            if theParent != dirent.inode and theParent != None:
                print("DIRECTORY INODE {} NAME {} LINK TO INODE {} SHOULD BE {}".format(dirent.parInodeNum, dirent.name, dirent.inode, dirent.parInodeNum))
                status = 2


def main():
    # Check number of arguments
    if len(sys.argv) != 2:
        print("Error: program takes 1 argument", file=sys.stderr)
        print("Usage: python lab3b.py <csv file name>", file=sys.stderr)
        sys.exit(1)

    superblock = None # struct
    group = None      # struct  
    freeBlocks = []    # array
    freeInodes = []    # array
    inodes = []        # array
    inodeStorage = dict()  # dict
    inodeRefs = dict() # dict
    dirents = []       # array
    indirects = []     # array

    
    # Open file
    try:
        with open(sys.argv[1], 'r') as infile:
            reader = csv.reader(infile, delimiter=",")
            for row in reader:
                if row[0] == 'SUPERBLOCK':
                    superblock = Superblock(row)
                if row[0] == 'BFREE':
                    freeBlocks.append(int(row[1]))
                if row[0] == 'IFREE':
                    freeInodes.append(int(row[1]))
                if row[0] == 'INODE':
                    inodes.append(Inode(row))
                    inodeEntry = Inode(row)
                    inodeStorage[int(row[1])] = inodeEntry
                if row[0] == 'DIRENT':
                    dirents.append(Dirent(row))
                if row[0] == 'INDIRECT':
                    indirects.append(Indirect(row))

    except (IOError):
        print("Error: failed to open file", file=sys.stderr)
        sys.exit(1)

    
    block_consistency_audit(superblock, group, freeBlocks, inodes, indirects)
    allocatedInodes = inode_allocation_audit(superblock, freeInodes, inodes)

    inodeRefs[2] = 0
    for i in range(superblock.firstNonReservedI,superblock.totalInodes + 1):
        inodeRefs[i] = 0
    for dirent in dirents:
        if int(dirent.inode) in inodeRefs:
            inodeRefs[int(dirent.inode)] += 1

    directory_consistency_audit(superblock, inodes, dirents, inodeRefs, inodeStorage, allocatedInodes, freeInodes)
    
    sys.exit(status)


if __name__ == "__main__":
    main()
