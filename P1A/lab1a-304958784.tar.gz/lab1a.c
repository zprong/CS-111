// Name: Zachary Prong
// Email: prongzachary@gmail.com
// ID: 304958784

#include <stdio.h>
#include <termios.h>   // termios, tcgetrr, tcsetattr
#include <unistd.h>    // above functions + pipe, exec, read
#include <poll.h>      // poll
#include <sys/types.h> // fork, waitpid
#include <sys/wait.h>  // waitpid
#include <signal.h>    // kill
#include <string.h>    // strerror
#include <getopt.h>    // getopt_long
#include <stdlib.h>    // exit, fprintf
#include <errno.h>     // var: errno
#include <fcntl.h>

const int LEN = 256;
int hasShell = 0;
pid_t pid = -1;
int bytesRead = -1;
int status;// = 0;
int ret = -1;

// Declaration of terminal modes
struct termios saved_terminal;
struct termios edited_terminal;

void print_error(void) {
  fprintf(stderr, "Error: %s\n", strerror(errno));
  exit(1);
}

void sig_handler(int sigNum) {
  if(sigNum == SIGPIPE)
    exit(0);
}

void restore_mode() {
  if (tcsetattr(0, TCSANOW, &saved_terminal) == -1) { print_error(); }

  waitpid(pid, &status, 0);
  if (hasShell)
    fprintf(stderr, "SHELL EXIT SIGNAL=%d STATUS=%d\r\n", status & 0x007f, (status & 0xff00) >> 8);
}

void set_mode(struct termios* saved_terminal, struct termios* edited_terminal) {
  
  if (!isatty(0)) { print_error(); }

  // Save Terminal Attributes
  if (tcgetattr(0, saved_terminal) == -1) { print_error(); } 
  atexit(restore_mode);

  // Edit Terminal Attributes
  if (tcgetattr(0, edited_terminal) == -1) { print_error(); }
  edited_terminal->c_iflag = ISTRIP; /* only lower 7 bits */
  edited_terminal->c_oflag = 0;      /* no processing */
  edited_terminal->c_lflag = 0;      /* no processing */
  
  // Set Attributes
  if (tcsetattr(0, TCSANOW, edited_terminal) == -1) { print_error(); }
}

void fork_poll() {
  // Handle Signals
  signal(SIGPIPE, sig_handler);

  // Pipes: [1]-Writing, [0]-Reading
  int child_pipes[2];
  int parent_pipes[2];
  
  // Create pipes
  if (pipe(child_pipes)  == -1) { print_error(); }
  if (pipe(parent_pipes) == -1) { print_error(); }

  // Create new process
  pid = fork();
  if (pid < 0) { // failure in creation of child process
    fprintf(stderr, "Error: Failed to create child process\n");
    exit(1);
  }

  // Child Process
  else if (pid == 0) {
    // Close Unused Pipes
    if (close(child_pipes[1] ) == -1) { print_error(); } 
    if (close(parent_pipes[0]) == -1) { print_error(); }
    // Dup 
    if (dup2(child_pipes[0]  , 0) == -1) { print_error(); } // stdin = pipe to shell
    if (dup2(parent_pipes[1] , 1) == -1) { print_error(); } // stdout = pipe to terminal
    if (dup2(parent_pipes[1] , 2) == -1) { print_error(); } // stderr = pipe to terminal
    
    if (close(parent_pipes[1]) == -1) { print_error(); }

    char* fname = "/bin/bash";
    char* procArgv[2] = { fname, NULL };

    // Exec Shell 
    if ( execvp(fname, procArgv) == -1) { // Should never return, so if it does, it must've failed
      fprintf(stderr, "execvp failed\n");
      exit(1);
    }
  }

  // Parent Process
  else {
    // Close Unused Pipes
    if (close(child_pipes[0] ) == -1) { print_error(); } 
    if (close(parent_pipes[1]) == -1) { print_error(); }
    
    struct pollfd pollfds[2];
    pollfds[0].fd = 0; // keyboard aka stdin
    pollfds[1].fd = parent_pipes[0]; // pipe that returns output from shell
    pollfds[0].events = POLLIN | POLLHUP | POLLERR;
    pollfds[1].events = POLLIN | POLLHUP | POLLERR;

    // Special Characters
    char esc = 0x04;       // ^D
    char interrupt = 0x03; // ^C
    char lf = 0x0A;        // \n
    char cr = 0x0D;        // \r
    char newln[2] = {cr, lf};
    
    // Buffer
    char input1[256];

    while(1) {
      ret = poll(pollfds, 2, 0);
      if (ret < 0 ) { print_error(); }
      
      // Read input from keyboard, echo to stdout, forward to shell
      else if (ret > 0) {
	// Pending input from keyboard
	if (pollfds[0].revents & POLLIN) {
	  bytesRead = read(0, input1, LEN);
	  if ( bytesRead == -1 ) { print_error(); }

	  // Process keyboard input
	  for(int i = 0; i < bytesRead; i++) {
	    if (input1[i] == lf || input1[i] == cr) { // '/r' or '/n'
	      if (write(1, newln, sizeof(char)*2) == -1) { print_error(); }
	      // Send to Shell!
	      if (write(child_pipes[1], &lf, sizeof(char)) == -1) { print_error(); }
	    }
	    // Close Pipe to Shell
	    else if (input1[i] == esc) { // '^D'
	      if (close(child_pipes[1]) == -1) { print_error(); }
	    }
	    // Send Kill Signal to Shell
	    else if (input1[i] == interrupt) { // '^C'
	      if (kill(pid, SIGINT) == -1) { print_error(); }
	    }
	    // Normal Characters
	    else {
	      write(1, &input1[i], sizeof(char));
	      write(child_pipes[1], &input1[i], sizeof(char));
	    }
	  }
	}
	// Handle Hangups and Errors From Shell
	if (pollfds[0].revents & (POLLHUP | POLLERR)) {
	  if (kill(pid, SIGINT) == -1) { print_error(); }
	  close(parent_pipes[0]);
	  exit(1);
        }
	// Pending Input From Shell
	if (pollfds[1].revents & POLLIN) {
	  bytesRead = read(pollfds[1].fd, input1, LEN);
	  if (bytesRead == -1) { print_error(); }

	  // Process Shell Input
	  for(int i = 0; i < bytesRead; i++) {
	    if (input1[i] == cr || input1[i] == lf) { // '/r' or '/n'
	      if (write(1, newln, sizeof(char)*2) == -1) { print_error(); }
	    }
	    else {
	      if (write(1, &input1[i], sizeof(char)) == -1) { print_error(); }
	    }
	  }
	}
	// Handle Hangups and Errors From Shell
	if (pollfds[1].revents & (POLLHUP | POLLERR)) {
	  close(parent_pipes[0]);
	  exit(1);
	}
      }
    }
  }
}

int main (int argc, char* argv[]) {  
  int c;
  while(1) {
    int option_index = 0;
    static struct option long_options[] = {
      {"shell", no_argument, 0, 's' }
    };
    
    c = getopt_long(argc, argv, "s", long_options, &option_index);
    if (c == -1)
      break;
    
    switch(c) {
    case 's':
      hasShell = 1;
      signal(SIGINT, sig_handler);
      break;
      
    case '?':
      fprintf(stderr, "Error: Unrecognized argument\n");
      fprintf(stderr, "Usage: ./lab1a --shell\n");
      exit(1);
      
    default:
      printf("?? getopt returned character code 0%o ??\n", c);
    }
  }

  // Set Mode for Terminal
  set_mode(&saved_terminal, &edited_terminal);
  
  // Has shell option
  if (hasShell) {
    fork_poll();
  }  
  // No shell option
  if (!hasShell) {
    char esc = 0x04; // '^D'
    char cr = 0x0D; // '\r'
    char lf = 0x0A; // '\n' 
    char input[256];
    
    while(1) {
      bytesRead = read(0, input, LEN);
      if (bytesRead == -1) {
	fprintf(stderr, "Error: read() was unsuccessful\n");
	exit(1);
      }

      // Read all bytes in buffer
      for(int i = 0; i < bytesRead; i++) {
	if (input[i] == esc) { // If escape sequence (^D) detected, restore terminal
	  write(1, &esc, sizeof(char));
	  exit(0);
	}
	else if  (input[i] == cr || input[i] == lf) { // '/r' or '/n'
	  if (write(1, &cr, sizeof(char)) == -1) { print_error(); }
	  if (write(1, &lf, sizeof(char)) == -1) { print_error(); }
	}
	else {
	  write(1, &input[i], sizeof(char));
	}
      }
    }
  }
  exit(0);
}
