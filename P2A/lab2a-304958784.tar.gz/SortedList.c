// Name: Zachary Prong
// Email: prongzachary@gmail.com
// ID: 304 958 784

#include "SortedList.h"
#include <sched.h>
#include <string.h>

void SortedList_insert(SortedList_t *list, SortedListElement_t *element) {
  // check if list is NULL and if element is NULL
  if (list == NULL || element == NULL)
    return;
  SortedListElement_t* current = list->next;
  
  // Identify node that would be after inserted element
  while(current != list) {
    // current key is greater than new elements key
    if (strcmp(current->key, element->key) > 0)
      break;
    current = current->next;
  }
  
  if (opt_yield & INSERT_YIELD)
    sched_yield();
  
  // Insert the element into list
  element->next = current;
  element->prev = current->prev;
  current->prev->next = element;
  current->prev = element;
}


int SortedList_delete( SortedListElement_t *element) {
  // Case 1: Check if element is null
  if (element == NULL)
    return 1;
    
  // Case 2: Check that the element is properly linked
  if (element->next->prev != element->prev->next)
    return 1;
  
  else {
    if (opt_yield & DELETE_YIELD)
      sched_yield();
    element->prev->next = element->next;
    element->next->prev = element->prev;
    return 0; // success in deletion!
  }
}

SortedListElement_t *SortedList_lookup(SortedList_t *list, const char *key) {
  // Check if head is NULL or if desired key is NULL
  if (list == NULL || key == NULL)
    return NULL;
  SortedListElement_t* current = list->next;

  // Traverse through linked list 
  while(current != list) {
    if (strcmp(current->key, key) == 0) // key matches string!
      return current;
    if (opt_yield & LOOKUP_YIELD)
      sched_yield();
    current = current->next;
  }
  return NULL;
}

int SortedList_length(SortedList_t *list) {
  if (list == NULL)
    return -1;
  int length = 0;
  SortedListElement_t* current = list->next;
  while(current != list) {
    length++;
    if (opt_yield & LOOKUP_YIELD)
      sched_yield();
    
    if (current->next->prev != current || current->prev->next != current)
      return -1;
    current = current->next;
  }
  return length;
}


