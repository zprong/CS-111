// Name: Zachary Prong
// Email: prongzachary@gmail.com
// ID: 304 958 784

//#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>  // fprintf, srand
#include <time.h>    // clockget
#include <unistd.h>  // getopt_long
#include <getopt.h>  // getopt_long
#include <pthread.h> // pthread stuff
#include <errno.h>   // errno
#include <string.h>  // strerror
#include <sched.h>   // sched_yield
#include "SortedList.h"
#include <signal.h>

// ====  Global variables ==================================
int nthreads = 1;
int nits = 1;
char testName[256] = "list-none-none";
int totalElems = 0;
int listLength = 0;
char syncType = '\0';
int exclusion = 0;

pthread_mutex_t mutex;

// Options
int opt_yield = 0;

// List
SortedList_t* list;
SortedListElement_t* elems;

// ===== FUNCTION: edit_list ====================================
void* edit_list(void* threadNum) {
  int tnum = *(int*)threadNum;
  
  // INSERT:
  for(int i = tnum; i < totalElems; i+= nthreads) {
    switch(syncType) {
    case 'm': 
      pthread_mutex_lock(&mutex);
      SortedList_insert(list, elems+i);
      pthread_mutex_unlock(&mutex);
      break;
      
    case 's':
      while(__sync_lock_test_and_set(&exclusion,1)); // spin
      SortedList_insert(list, elems+i);
      __sync_lock_release(&exclusion);
      break;
      
    default: // NULL
      SortedList_insert(list, elems+i);
      break;
    }
  }

  // LENGTH:
  switch(syncType) {
  case 'm':
    pthread_mutex_lock(&mutex);
    if (SortedList_length(list) == -1) {
      fprintf(stderr, "Error: Corrupted list found from length!\n");
      exit(2);
    }
    pthread_mutex_unlock(&mutex);
    break;
  case 's':
    while(__sync_lock_test_and_set(&exclusion,1)); // spin
    if (SortedList_length(list) == -1) {
      fprintf(stderr, "Error: Corrupted list found from length!\n");
      exit(2);
    }
    __sync_lock_release(&exclusion);
    break;
  default:
    if (SortedList_length(list) == -1) {
      fprintf(stderr, "Error: Corrupted list found from length!\n");
      exit(2);
    }
    break;
  }
  
  // LOOKUP + DELETE: 
  for(int j = tnum; j < totalElems; j += nthreads) {
    SortedListElement_t* tempElem;
    switch(syncType) {
    case 'm':
      pthread_mutex_lock(&mutex);
      tempElem = SortedList_lookup(list, elems[j].key);
      if (tempElem == NULL) {
	fprintf(stderr, "Error: Corrupted list found from lookup!\n");
	exit(2);
      }
      if (SortedList_delete(tempElem) == 1) {
      	fprintf(stderr,"Error: Corrupted list found from delete!\n");
	exit(2);
      }
      pthread_mutex_unlock(&mutex);
      break;
      
    case 's':
      while(__sync_lock_test_and_set(&exclusion,1)); // spin
      tempElem = SortedList_lookup(list, elems[j].key);
      if (tempElem == NULL) {
	fprintf(stderr,"Error: Corrupted list found from lookup!\n");
	exit(2);
      }
      if (SortedList_delete(tempElem) == 1) {
      	fprintf(stderr,"Error: Corrupted list found from delete!\n");
	exit(2);
      }
      __sync_lock_release(&exclusion);
      break;
      
    default:
      tempElem = SortedList_lookup(list, elems[j].key);
      if (tempElem == NULL) {
	fprintf(stderr,"Error: Corrupted list found from lookup!\n");
	exit(2);
      }
      if (SortedList_delete(tempElem) == 1) {
      	fprintf(stderr,"Error: Corrupted list found from delete!\n");
	exit(2);
      }
      break;
    }
  }
  return NULL;
}

// ======== FUNCTION: print_error =====================================

void print_error(char* error) {
  fprintf(stderr, "Error: %s - %s\n", error, strerror(errno));
  exit(1);
}


// ===== FUNCTION: sig_handler =================================
void sig_handler(int sigNum) {
  if(sigNum == SIGSEGV) {
    fprintf(stderr,"Error: segmentation fault\n");
    exit(1);
  }
}

// ========= main =====================================================
int main(int argc, char* argv[]) {
  int c;
  int option_index;
  int length = 0;
  
  // Yield options
  int yieldopts[3] = { 0, 0, 0 }; // insert, delete, lookup
  
  // Time variables
  struct timespec start,finish;

  static struct option long_options[] = {
    {"threads",    required_argument, 0, 't'},
    {"iterations", required_argument, 0, 'i'},
    {"yield",      required_argument, 0, 'y'},
    {"sync",       required_argument, 0, 's'}
  };
  
  while(1) {
    option_index = 0;
    c = getopt_long(argc, argv, "t:i:s:y:", long_options, &option_index);
    if (c == -1)
      break;

    switch(c) {
    case 't':
      nthreads = atoi(optarg);
      break;
    case 'i':
      nits = atoi(optarg);
      break;
    case 'y':
      length = strlen(optarg);
      for (int i = 0; i < length; i++) {
	if (optarg[i] == 'i') {
	  opt_yield |= INSERT_YIELD;
	  yieldopts[0] = 1;
	}
	else if (optarg[i] == 'd') {
	  opt_yield |= DELETE_YIELD;
	  yieldopts[1] = 1;
	}
	else if (optarg[i] == 'l') {
	  opt_yield |= LOOKUP_YIELD;
	  yieldopts[2] = 1;
	}
	else
	  print_error("--yield=[idl]");
      }
      //opt_yield = 1;      
      //strcpy(testName, "add-yield-none");
      // testName = "add-yield-none"; // add-yield if with syncronization
      break;
    case 's':
      if(strlen(optarg) != 1)
	print_error("--sync takes a single character");
      syncType = optarg[0];
      break;
    case '?':
      fprintf(stderr, "Error: Unrecognized argument\n");
      fprintf(stderr, "Usage: ./lab2_list --threads=# --iterations=#\n");
      exit(1);
    default:
      printf("?? getopt returned character code 0%o ??\n", c);
    }
  }
  
  // Take care of sync options
  if (syncType != 'm' && syncType != 's' && syncType != '\0')
    print_error("--sync=[m]utex, [s]pin");

  if (opt_yield) {
    char str_yield[4] = { '\0' };
    int str_offset = 0;
    if (yieldopts[0]) {
      str_yield[str_offset] = 'i';
      str_offset++;
    }
    if (yieldopts[1]) {
      str_yield[str_offset] = 'd';
      str_offset++;
    }
    if (yieldopts[2]) {
      str_yield[str_offset] = 'l';
      str_offset++;
    }

    // Change testName
    strcpy(testName, "list-");
    strcat(testName, str_yield);

    switch(syncType) {
    case 'm':     
      strcat(testName, "-m");
      break;
    case 's':
      strcat(testName, "-s");
      break;
    default:
      strcat(testName, "-none");
      break;
    }
  }

  else { // no yield argument
    switch(syncType) {
    case 'm':     
      strcpy(testName, "list-none-m");
      break;
    case 's':
      strcpy(testName, "list-none-s");
      break;
    default: // leave as "list-none-none"
      break;
    }
  }

  if (syncType == 'm')
    pthread_mutex_init(&mutex, NULL);
    
  // Thread variables
  pthread_t threads[nthreads];
  pthread_t tids[nthreads];
  
  totalElems = nits * nthreads;
  
  // Initalize empty circular doubly linked list
  signal(SIGSEGV,sig_handler);
  list = malloc(sizeof(SortedList_t));
  list->next = list;
  list->prev = list;
  list->key = NULL;

  
  // Create and initalize list elements with RANDOM keys
  elems = malloc(totalElems * sizeof(SortedListElement_t)); 
  
  srand(time(0)); // initalizes RNG
  int letter;
  char* key;
  length = 0;
  for(int i = 0; i < totalElems; i++) {
    length = rand() % 8 + 4; // Generates a string of length 4-8
    key = malloc(sizeof(char) * (length + 1)); // length of string + NULL
    
    for (int j = 0; j < length; j++) {
      letter = rand() % 26; // Generates number 0 to 26
      key[j] = 'a' + letter; // a to z lowercase
    }
    key[length] = '\0';
    elems[i].key = key;

    listLength = SortedList_length(list);
  }
  
  // Get start timer
  if (clock_gettime(CLOCK_MONOTONIC, &start) == -1)
    print_error("failed to get start time");
  
  // printf("Threading begins now. Start time is %lld\n", startTime);
  for(int j = 0; j < nthreads; j++) {
    tids[j] = j;
    if (pthread_create(&threads[j], NULL, edit_list, tids+j) !=  0)
      print_error("failed to create thread");
  }

  
  // Join threads
  for(int k = 0; k < nthreads; k++)
    if (pthread_join(threads[k], NULL))
      print_error("failed to join thread");

  
  // Get finish timer
  if (clock_gettime(CLOCK_MONOTONIC, &finish) == -1)
    print_error("failed to get finish time");

  // long long startTime = (1000000000*start.tv_sec) + start.tv_nsec;
  // long long finishTime = (1000000000*finish.tv_sec) + finish.tv_nsec;
  // printf("Threading has finished. Finished at %lld\n", finishTime);
  //  long long totalTime = finishTime - startTime;
  long long totalTime = 1000000000*(finish.tv_sec-start.tv_sec) +
    (finish.tv_nsec - start.tv_nsec);
 
   // Free elements
  free(elems);
  free(list);
  
  // Calculate total ops (threads * iterations) 
  long long totalOps =  nthreads * nits * 3;
  
  // Calculate average time
  long long avgTime = totalTime / totalOps;
  int numLists = 1;
  
  printf("%s,%d,%d,%d,%lld,%lld,%lld\n",				\
	 testName, nthreads, nits, numLists, totalOps,			\
	 totalTime, avgTime);
  
  if (listLength != 0) {
    fprintf(stderr,"list length is not zero");
    exit(2);
  }

  exit(0);
}
