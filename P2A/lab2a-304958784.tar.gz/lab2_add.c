// Name: Zachary Prong
// Email: prongzachary@gmail.com
// ID: 304 958 784

#include <stdio.h>
#include <stdlib.h>  // fprintf
#include <time.h>    // clockget
#include <unistd.h>  // getopt_long
#include <getopt.h>  // getopt_long
#include <pthread.h> // pthread stuff
#include <errno.h>   // errno
#include <string.h>  // strerror
#include <sched.h>   // sched_yield

// Global variables
// long long counter = 0;
int nthreads = 1;
int nits = 1;
char testName[256] = "add-none";
int exclusion = 0;

pthread_mutex_t mutex;

// Options
int opt_yield = 0;
char syncType = 0;

void add(long long *pointer, long long value) {
  long long sum = *pointer + value;
  if (opt_yield)
    sched_yield();
  *pointer = sum;
  return;
}

void cas_add(long long *pointer, long long value) {
  long long prev;
  long long sum;
  do {
    prev = *pointer;
    sum = prev + value;
    if (opt_yield)
      sched_yield();
  } while(__sync_val_compare_and_swap(pointer, prev, sum) != prev);
}

void* sum_iterator(void* totalSum) {
  // add 1 for every iter
  for(int i = 0; i < nits; i++) {
    switch(syncType) {
    case 'm': 
      pthread_mutex_lock(&mutex);
      add((long long*) totalSum, 1);
      pthread_mutex_unlock(&mutex);
      break;
    case 's':
      while(__sync_lock_test_and_set(&exclusion,1)); // spin
      add((long long*) totalSum, 1);
      __sync_lock_release(&exclusion);
      break;
    case 'c':
      cas_add((long long*) totalSum, 1);
      break;
    default: // NULL
      add((long long*) totalSum, 1);
      break;
    }
  }

  // subtract 1 for every iter
  for(int j = 0; j < nits; j++) {
    switch(syncType) {
    case 'm':
      pthread_mutex_lock(&mutex);
      add((long long*) totalSum, -1);
      pthread_mutex_unlock(&mutex);
      break;
    case 's':
      while(__sync_lock_test_and_set(&exclusion,1)); // spin
      add((long long*) totalSum, -1);
      __sync_lock_release(&exclusion);
      break;
    case 'c':
      cas_add((long long*) totalSum, -1);
      break;
    default:
      add((long long*) totalSum, -1);
      break;
    }
  }

  return NULL;
}

void print_error(char* error) {
  fprintf(stderr, "Error: %s - %s\n", error, strerror(errno));
  exit(1);
}

int main(int argc, char* argv[]) {
  int c;
  int option_index;
  
  // Time variables
  struct timespec start,finish;
  
  while(1) {
    option_index = 0;
    static struct option long_options[] = {
      {"threads",    required_argument, 0, 't'},
      {"iterations", required_argument, 0, 'i'},
      {"yield",      no_argument,       0, 'y'},
      {"sync",       required_argument, 0, 's'}
    };

    c = getopt_long(argc, argv, "t:i:y:s", long_options, &option_index);
    if (c == -1)
      break;

    switch(c) {
    case 't':
      nthreads = atoi(optarg);
      break;
    case 'i':
      nits = atoi(optarg);
      break;
    case 'y':
      opt_yield = 1;
      strcpy(testName, "add-yield-none");
      // testName = "add-yield-none"; // add-yield if with syncronization
      break;
    case 's':
      if(strlen(optarg) != 1)
	print_error("--sync takes a single character");
      syncType = optarg[0];
      break;
    case '?':
      fprintf(stderr, "Error: Unrecognized argument\n");
      fprintf(stderr, "Usage: ./lab2_add --threads=# --iterations=#\n");
      exit(1);
    default:
      printf("?? getopt returned character code 0%o ??\n", c);
    }
  }
  
  // Take care of sync options
  if (syncType != 'm' && syncType != 's' && syncType != 'c' && syncType != 0)
    print_error("--sync=[m]utex, [s]pin, [c]ompare-and-swap");

  if (opt_yield) { 
    switch(syncType) {
    case 'm':     
      strcpy(testName, "add-yield-m");
      break;
    case 's':
      strcpy(testName, "add-yield-s");
      break;
    case 'c':
      strcpy(testName, "add-yield-c");
      break;
    default:
      strcpy(testName, "add-yield-none");
      break;
    }
  }

  else { // no yield argument
    switch(syncType) {
    case 'm':     
      strcpy(testName, "add-m");
      break;
    case 's':
      strcpy(testName, "add-s");
      break;
    case 'c':
      strcpy(testName, "add-c");
      break;
    default:
      strcpy(testName, "add-none");
      break;
    }
  }

  // Thread variables
  pthread_t threads[nthreads];
  
  // Get start timer
  clock_gettime(CLOCK_MONOTONIC, &start);
  long long totalSum = 0;
  long long startTime = (1000000000*start.tv_sec) + start.tv_nsec;

  // printf("Threading begins now. Start time is %lld\n", startTime);

  for(int i = 0; i < nthreads; i++)
    if (pthread_create(&threads[i], NULL, sum_iterator, &totalSum) !=  0)
      print_error("failed to create thread");
  
  // Join threads
  for(int j = 0; j < nthreads; j++)
    if (pthread_join(threads[j], NULL))
      print_error("failed to join thread");
  
  // Get finish timer
  clock_gettime(CLOCK_MONOTONIC, &finish);
  
  long long finishTime = (1000000000*finish.tv_sec) + finish.tv_nsec;
  // printf("Threading has finished. Finished at %lld\n", finishTime);
  
  long long totalTime = finishTime - startTime;
  
  // Calculate total ops 
  long long totalOps =  nthreads * nits * 2;
  
  // Calculate average time
  long long avgTime = totalTime / totalOps;

  // printf("[testname],[numthreads],[numiters],[numOps],[totaltime],[averagetime],[total]\n");
  
  printf("%s,%d,%d,%lld,%lld,%lld,%lld\n",				\
	 testName, nthreads, nits, totalOps, totalTime, avgTime, totalSum);
  /*
  if(totalSum != 0) {
    fprintf(stderr, "Error: concurrency issues - total sum = %lld\n",
	    totalSum);
    exit(2);
  }
  */

  return 0;
}
