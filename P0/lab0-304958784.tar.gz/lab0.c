#include <stdio.h>  // fprintf
#include <unistd.h> // read,dup,write,exit,
#include <getopt.h> // getopt_long
#include <signal.h> // signal
#include <string.h> // strerror, strcmp
#include <stdlib.h> // library macros,exit
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>  // errno

typedef struct {
  const char* argument;
  const char* option;
} Arg;
void sighandler(int);

int main(int argc, char* argv[]) {
    int c;
    Arg args[4];
    int i;
    int numArgs = 0;
    int argFound;
    
    while (1) {
      // int this_option_optind = optind ? optind : 1;
	  int option_index = 0;
	  static struct option long_options[] = {
	  	 {"input",     required_argument, 0, 0 },
		 {"output",    required_argument, 0, 0 },
		 {"segfault",  no_argument,	  0, 0 },
		 {"catch",     no_argument,	  0, 0 },
		 {0,	       0,		  0, 0 }
	  };
	  c = getopt_long(argc, argv, "", long_options, &option_index);
	  if (c == -1)
	    break;
	  
	  switch(c) {
	    case 0:
	      args[numArgs].argument = long_options[option_index].name; 
	      if (optarg) {
		args[numArgs].option = optarg;
	      }
	      else
		args[numArgs].option = NULL;
	      numArgs++;
	      break;
	    case '?':
	      fprintf(stderr, "Error: Unrecognized argument\n");
	      fprintf(stderr, "Usage: ./lab0 --input=filepath \
--output=filepath --segfault --catch\n");
	      exit(1);
	    
	    default:
	      printf("?? getopt returned character code 0%o ??\n", c);
	  }	 
    }

    if (optind < argc) {
      printf("non-option ARGV-elements: ");
      while (optind < argc)
	printf("%s ", argv[optind++]);
      printf("\n");
      fprintf(stderr, "Usage: only long arguments accepted. Use -- ");
      exit(1);
    }
    /*
    for(i = 0; i < numArgs; i++) {
      printf("Argument %d\t Arg: %s\t ", i, args[i].argument);
      if (args[i].option != NULL) 
	printf("Option: %s", args[i].option);
      printf("\n");
    }
    */
    argFound = 0;
    for(i = 0; i < numArgs; i++) {  // find "input" in array
      if (strcmp(args[i].argument, "input") == 0) {
	argFound = 1;
	break;
      }
    }   
    if (argFound) {
      int inFD = open(args[i].option, O_RDONLY);
      if (inFD < 0) {  
	fprintf(stderr, "%s could not be opened as input: no such file - %s\n",
		args[i].option, strerror(errno));
	exit(2);
      }
      close(0);
      dup(inFD);
      close(inFD);
    }

    argFound = 0;
    for(i = 0; i < numArgs; i++) { // find "output" in array
      if (strcmp(args[i].argument, "output") == 0) {
	argFound = 1;
	break;
      }
    }
    if (argFound) {
      int outFD = creat(args[i].option, S_IWUSR | S_IRUSR);
      if (outFD < 0) {
	fprintf(stderr, "%s could not be opened as output - %s\n",
		args[i].option, strerror(errno));
	exit(3);
      }
      close(1);
      dup(outFD);
      close(outFD);
    }

    argFound = 0;
    for(i = 0; i < numArgs; i++) {  // find "segfault" in array
      if (strcmp(args[i].argument, "segfault") == 0) {
	argFound = 1;
	break;
      }
    }
    if (argFound) {
      argFound = 0;
      for(i = 0; i < numArgs; i++) {  // find "catch" in array
	if (strcmp(args[i].argument, "catch") == 0) {
	  argFound = 1;
	  break;
	}
      }
      if (argFound) {
	signal(SIGSEGV, sighandler);
      }
      char* seg = NULL;
      printf("%c", *seg); // cause segfault!
    }

    char* buf;
    buf = (char*)malloc(sizeof(char));
    while( read(0, buf, 1) ) {
      write(1, buf, 1);
    }
    free(buf);
    
    exit(0);
}

void sighandler(int signum) {
  if(signum == SIGSEGV) {
    fprintf(stderr, "error: segmentation fault - %s\n",strerror(errno));
    exit(4);
  }
}
		      
