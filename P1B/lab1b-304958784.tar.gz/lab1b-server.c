// Name: Zachary Prong
// ID: 304 958 784
// Email: prongzachary@gmail.com

#include <stdio.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h> // strlen
#include <stdlib.h> // exit, atoi
#include <unistd.h> // read, write
#include <getopt.h> // getopt_long
#include <fcntl.h> // creat 
#include <poll.h> // poll
#include <signal.h> // signal, signal modes
#include <termios.h> // terminals
#include <sys/wait.h> // waitpid
#include <zlib.h>

// Global Variables
const int LEN = 256;

pid_t pid = -1;
int status;

int pipe2child[2];
int pipe2parent[2];

char input1[256];
int newsockfd = 0;
int opt_compress = 0;

// Terminals
struct termios saved_terminal;
struct termios edited_terminal;

struct pollfd pollfds[2];

// Compression variables
z_stream to_client;
z_stream to_server;

// Other Globals
char newLn[2] = "\r\n";
char* shellNewLn = "\n";
int bytesRead = 0;

void error(char *msg)
{
  fprintf( stderr, "ERROR: %s\n", msg);
  exit(1);
}

void get_status() {
  shutdown(newsockfd, SHUT_RDWR);
  close(newsockfd);
  if (waitpid(pid, &status, 0) == -1)
    error("waitpid() failed");
  else
    fprintf(stderr, "SHELL EXIT SIGNAL=%d STATUS=%d\r\n", WIFEXITED(status), WIFSIGNALED(status));
  
}

void sig_handler(int sigNum) {
  /*
  if (sigNum == SIGINT) {
    kill(pid, SIGINT);
  }
  */
  if(sigNum == SIGPIPE) {
    while(1) {
      if (pollfds[1].revents & POLLIN) {
	bytesRead = read(pipe2parent[0], input1, LEN);
	if (bytesRead < 0)
	  error("Failed to read from pipe2parent[0]");
	for(int i = 0; i < bytesRead; i++) {
	  if (input1[i] == '\n') {
	    if (write(STDOUT_FILENO, newLn, 2) < 0) {
	      error("failed to write to stdout");
	    }
	  }
	  else if (input1[i] == 0x04) {
	    exit(0);
	  }
	  else {
	    if (write(newsockfd, &input1[i], sizeof(char)) < 0) {
	      error("failed to write to stdout");
	    }
	  }
	}
	if (pollfds[0].revents & (POLLERR | POLLHUP))
	  exit(0);
	if (pollfds[1].revents & (POLLERR | POLLHUP))
	  exit(0);
      }
      exit(0);
    }
  }
}

void clean_compress() {
  deflateEnd(&to_client);
  inflateEnd(&to_server);
}

void set_compress() {
  if (atexit(clean_compress) == -1)
    error("failed to call clean_compress on exit");
  to_client.zalloc = Z_NULL;
  to_client.zfree  = Z_NULL;
  to_client.opaque = Z_NULL;
  if (deflateInit(&to_client, Z_DEFAULT_COMPRESSION) < 0)
    error("failed to initialize compression");

  to_server.zalloc = Z_NULL;
  to_server.zfree = Z_NULL;
  to_server.opaque = Z_NULL;
  if (inflateInit(&to_server) < 0)
    error("failed to initialized decompression");
}

int compression(char* input, int numRead) {
  char temp[LEN];
  memcpy(temp, input, numRead);
  to_client.avail_in = numRead;
  to_client.avail_out = LEN;
  to_client.next_in = (Bytef*) temp;
  to_client.next_out = (Bytef*) input;

  do {
    deflate(&to_client, Z_SYNC_FLUSH);
  } while (to_client.avail_in != 0);
  return (LEN - to_client.avail_out);
}

int decompression(char* input, int numRead) {
  char temp[LEN];
  memcpy(temp, input, numRead);
  to_server.avail_in = numRead;
  to_server.avail_out = LEN;
  to_server.next_in = (Bytef*) temp;
  to_server.next_out = (Bytef*) input;

  do {
    inflate(&to_server, Z_SYNC_FLUSH);
  } while (to_server.avail_in != 0);

  return (LEN - to_server.avail_out);
}

void fork_poll() {
  int retVal;
  
  // Create pipes
  if (pipe(pipe2child) == -1) { error("pipe(pipe2child) failed"); }
  if (pipe(pipe2parent) == -1) { error("pipe(pipe2parent) failed"); }
  
  // Create new process and exec a shell
  pid = fork();
  if (pid == -1) { // failure in creation of child process
    fprintf(stderr, "Failed to create child process\n");
    exit(1);
  }
  
  else if (pid == 0) { // success in creation of child process
    if (close(pipe2child[1]) == -1)
      error("failed to close pipe2child[1] in child");
    if (close(pipe2parent[0]) == -1)
      error("failed to close pipe2parent[0] in child");
    if (close(newsockfd))
      error("failed to close newsockfd"); 
    
    if (dup2 (pipe2child[0],STDIN_FILENO) == -1)
      error("failed to dup pipe2child[0]");
    if (dup2 (pipe2parent[1],STDOUT_FILENO) == -1)
      error("failed to dup pipe2parent[1] to stdin");
    if (dup2 (pipe2parent[1],STDERR_FILENO) == -1)
      error("failed to dup pipe2parent[1] to stderr");   
     if (close(pipe2child[0]) == -1)    { error("failed to close pipe2child[0] in child"); }
    if (close(pipe2parent[1]) == -1)   { error("failed to close pipe2parent[1] in child"); }

    char* procArgv[2]; // = { "/bin/bash", NULL };
    char* execvp_fname = "/bin/bash";
    procArgv[0] = execvp_fname;
    procArgv[1] = NULL;
    if ( execvp(execvp_fname, procArgv) == -1) { // Should never return, so if it does, it must've failed
      fprintf(stderr, "execvp failed\n");
      exit(1);
    }
    exit(1);
  }

  else if (pid > 0) { // parent process
    if (close(pipe2child[0]) == -1)
      error("failed to close pipe2child[0] in parent");
    if (close(pipe2parent[1]) == -1)
      error("failed to close pipe2parent[1] in parent");

    signal(SIGPIPE, sig_handler);
    atexit(get_status);
    // signal(SIGINT, sig_handler);
    
    while(1) {
      retVal = poll(pollfds, 2, 0);
      if (retVal < 0 ) { error("failed to poll"); }
      // Read input from keyboard, echo to stdout, forward to shell
      else if (retVal > 0) {

	// Read from server to shell
        if (pollfds[0].revents & POLLIN) { // There's data to read from keyboard
          bytesRead = read(newsockfd, input1, LEN);
          if ( bytesRead == -1 ) { error("failed to read bytes"); }
	  
	  if (opt_compress) 
	    bytesRead = decompression(input1, bytesRead);
	    
	  //else if (bytesRead == 0) {
	    //	    kill(pid, SIGTERM);
	  //  exit(1);
	  //}
    
          for(int i = 0; i < bytesRead; i++) {
            if (input1[i] == '\r' || input1[i] == '\n') { // '\r' or '\n'
              if (write(1, newLn, sizeof(char)+1) == -1)
		error("failed to write bytes");
              if (write(pipe2child[1], shellNewLn, sizeof(char)) == -1)
		error("failed to write to pipe2child[1]");
            }
	    
            else if (input1[i] == 0x04) { // '^D'
              if (close(pipe2child[1]) == -1)
		error("failed to close pipe2child[1] in parent"); // close write side of pipe to the shell
            }
	    
            else if (input1[i] == 0x03) { // '^C'
              if (kill(pid, SIGINT) == -1) { error("failed to kill"); }
            }
	    
            else {
              // write(1, &input1[i], sizeof(char));
              write(pipe2child[1], &input1[i], sizeof(char));
            }
          }
        }
	
	// Read from shell to server
        if (pollfds[1].revents & POLLIN) { // There's data to be read from the shell
          // bytesRead = read(pollfds[1].fd, input1, LEN);
	  bytesRead = read(pipe2parent[0],input1, LEN);
	  if (bytesRead == -1)
	    error("failed to read from pollfds[1].fd");
	  
          for(int i = 0; i < bytesRead; i++) {
            // if (input1[i] == 0x0D || input1[i] == 0x0A) { // '/r' or '/n'
            //  if (write(newsockfd, newLn, sizeof(char)+1) == -1 ) { error("failed to write newline"); }
	    if (input1[i] == 0x04)
	      exit(0);
	  }

	  if (opt_compress)
	    bytesRead = compression(input1, bytesRead);
	  
	  if (write(newsockfd, input1, bytesRead) == -1)
	    error("failed to write input");
        }
        if (pollfds[1].revents & (POLLHUP | POLLERR)) {
          exit(0);
        }
	if (pollfds[0].revents & (POLLHUP | POLLERR)) {
          exit(0);
        }
      }
    }
  } 
}

int main(int argc, char *argv[]) {
  int sockfd;
  int portno = -1;
  socklen_t clilen;
  struct sockaddr_in serv_addr, cli_addr;
  int c;

  while(1) {
    int option_index = 0;
    static struct option long_options[] = {
      {"port",     required_argument, 0, 'p' },
      {"compress", no_argument,       0, 'c' }
    };

    c = getopt_long(argc, argv, "p:l:c", long_options, &option_index);
    if (c == -1)
      break;

    switch(c) {
    case 'p':
      portno = strtol(optarg, NULL, 10);// atoi(optarg);
      break;
    case 'c':
      opt_compress = 1;
      set_compress();
      break;
    case '?':
      fprintf(stderr, "Error: Unrecognized argument\n");
      fprintf(stderr, "Usage: ./lab1a --port=portno [--log=filename]\n");
      exit(1);
    default:
      printf("?? getopt returned character code 0%o ??\n", c);
    }
  }

  if (portno == -1) { error("no port provided"); }
  else if (portno < 1025) {
    fprintf(stderr, "portno must be greater than 1024\n");
    exit(1);
  }
  
  // set_mode();
  
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0) 
    error("failed to open socket");
  memset((char *) &serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = INADDR_ANY;
  serv_addr.sin_port = htons(portno);
  if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) 
    error("ERROR on binding");
  
  listen(sockfd,5);
  clilen = sizeof(cli_addr);
  
  newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
  if (newsockfd < 0) 
    error("ERROR on accept");

  pollfds[0].fd = newsockfd; // keyboard/stdin
  pollfds[1].fd = pipe2parent[0]; // pipe that returns output from shell
  pollfds[0].events = POLLIN | POLLHUP | POLLERR;
  pollfds[1].events = POLLIN | POLLHUP | POLLERR;
  
  fork_poll();
  
  exit(0); 
}
