// Name: Zachary Prong
// ID: 304 958 784
// Email: prongzachary@gmail.com

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <stdlib.h> // atoi, exit
#include <unistd.h> // write, read
#include <string.h> // strlen
#include <getopt.h> // getopt_long 
#include <fcntl.h> // creat
#include <poll.h> // poll
#include <termios.h> // terminal 
#include <sys/wait.h> // waitpid
#include <zlib.h>

// Global Variables
int LEN = 256;

int pipe2child[2];
int pipe2parent[2];

char input1[256];
int bytesRead = 0;

struct termios saved_terminal;
struct termios edited_terminal;

struct pollfd pollfds[2];

int opt_compress = 0;
int opt_log = 0;
int logFD = -1;
char newLn[2] = "\r\n";

z_stream to_shell;
z_stream from_shell;
int sockfd;

void error(char *msg) {
  fprintf(stderr, "ERROR: %s\n", msg);
  exit(1);
}

void reset_mode() {
  if (tcsetattr(0, TCSANOW, &saved_terminal) == -1)
    error("Couldn't set saved terminal");
}

void set_mode() {
  if (tcgetattr(0, &saved_terminal) == -1)
    error("couldn't get saved terminal attributes");
  atexit(reset_mode);

  if (tcgetattr(0, &edited_terminal) == -1)
    error("couldnt get edited terminal attributes");
  edited_terminal.c_iflag = ISTRIP; /* only lower 7 bits */
  edited_terminal.c_oflag = 0;      /* no processing */
  edited_terminal.c_lflag = 0;      /* no processing */
  if (tcsetattr(0, TCSANOW, &edited_terminal) == -1)
    error("couldnt set edited terminal attributes");
}

void clean_compression() {
  deflateEnd(&to_shell);
  inflateEnd(&from_shell);
}

void set_compression() {
  if (atexit(clean_compression) == -1)
    error("couldn't exit with clean_compressionn)");
  to_shell.zalloc = Z_NULL;
  to_shell.zfree = Z_NULL;
  to_shell.opaque =Z_NULL;
  
  if (deflateInit(&to_shell, Z_DEFAULT_COMPRESSION) != Z_OK)
    error("couldn't initialize for compression");

  from_shell.zalloc = Z_NULL;
  from_shell.zfree = Z_NULL;
  from_shell.opaque = Z_NULL;
  if (inflateInit(&from_shell) != Z_OK)
    error("couldn't initialize for decompression");
}

int compression(char* input, int numRead) {
  char temp[LEN];
  memcpy(temp, input, numRead);
  to_shell.avail_in = numRead;
  to_shell.avail_out = LEN;
  to_shell.next_in = (Bytef*)temp;
  to_shell.next_out = (Bytef*)input;

  do {
    deflate(&to_shell, Z_SYNC_FLUSH);
  } while(to_shell.avail_in != 0);

  return (LEN - to_shell.avail_out);
}

int decompression(char* input, int numRead) {
  char temp[LEN];
  memcpy(temp, input, numRead);
  from_shell.avail_in = numRead;
  from_shell.avail_out = LEN;
  from_shell.next_in = (Bytef*)temp;
  from_shell.next_out = (Bytef*)input;

  return (LEN - from_shell.avail_out);
}

void read_write() {
  
  while(1) {
    int retVal = poll(pollfds, 2, 0);
    if (retVal < 0 ) { error("failed to poll"); }
    
    // Read input from keyboard, echo to stdout, send through socket
    else if (retVal > 0) {
      // Client to server
      if (pollfds[0].revents & POLLIN) { // There's data to read from keyboard
	bytesRead = read(STDIN_FILENO, input1, LEN);
	if (bytesRead == -1) { error("failed to read bytes"); }
	
	for(int i = 0; i < bytesRead; i++) {
	  if (input1[i] == '\r' || input1[i] == '\n') { // '\r' or '\n'
	    if (write(STDOUT_FILENO, newLn, sizeof(char)+1) == -1)
	      error("failed to write bytes");
	    //if (write(sockfd, "\r", sizeof(char)) == -1) { error("failed to write to sockfd"); }}
	  }
	  else {
	    if (write(STDOUT_FILENO, &input1[i], sizeof(char)) == -1)
	      error("failed to write to stdout");
	     if (write(sockfd, &input1[i], sizeof(char)) == -1)
	       error("failed to write to sockfd");
	    if (opt_log)
	      if (write(logFD, &input1[i], sizeof(char)) == -1)
		error("failed to write to logFD");
	  }
	}
	
	for(int i = 0; i < bytesRead; i++) 
	  if (input1[i] == '\r')
	    input1[i] = '\n';
	
	if (opt_compress) 
	  bytesRead = compression(input1, bytesRead);
	
	write(pollfds[1].fd, input1, bytesRead);
	
	if (opt_log) {
	  dprintf(logFD, "Sent %d bytes: ", bytesRead);
	  write(logFD, input1, bytesRead);
	  dprintf(logFD, "\n");
	}
      }
      
      if (pollfds[0].revents & (POLLHUP | POLLERR)) {
	exit(0);
      }
      
      // Server to client
      if (pollfds[1].revents & POLLIN) { // There's data to be read from the shell
	bytesRead = read(pollfds[1].fd, input1, LEN);
	if (bytesRead == -1)
	  error("ERROR: read failed for pollfds[1]");
	else if (bytesRead == 0) // received ^C
	  exit(0);
	
	// report number of bytes received
	if (opt_log) {
	  dprintf(logFD, "Received %d bytes: ", bytesRead);
	  write(logFD, input1, bytesRead);
	  dprintf(logFD, "\n");
	}
	if (opt_compress)
	  bytesRead = decompression(input1, bytesRead);
	for(int i = 0; i < bytesRead; i++) {
	  if (input1[i] == '\n') {
	    char newLn[2] = "\r\n";
	    if (write(1, newLn, sizeof(char)+1) == -1)
	      error("ERROR: failed to write newline");
	  }
	  else 
	    if (write(1, &input1[i], sizeof(char)) == -1)
	      error("ERROR: failed to write input");
	}
      }
      
      if (pollfds[1].revents & (POLLHUP | POLLERR))
	exit(0);
    }
  }
}

int main(int argc, char *argv[])
{
  int portno = -1;
  //  int n;  
  struct sockaddr_in serv_addr;
  struct hostent *server;
  
  //  char buffer[256];
  /*
  if (argc < 3) {
    fprintf(stderr,"usage %s hostname port\n", argv[0]);
    exit(0);
  }
  */
  int c;
  
  while(1) {
    int option_index = 0;
    static struct option long_options[] = {
      {"port",     required_argument, 0, 'p' },
      {"log" ,     required_argument, 0, 'l' },
      {"compress", no_argument,  0, 'c' }
    };
  
    c = getopt_long(argc, argv, "p:l:c", long_options, &option_index);
    if (c == -1)
      break;
    
    switch(c) {
    case 'p':
      portno = strtol (optarg, NULL, 10);// atoi(optarg);
      break;
    case 'c':
      opt_compress = 1;
      set_compression();
      break;
    case 'l':
      opt_log = 1;
      logFD = creat(optarg, S_IRWXU);
      break;
    case '?':
      fprintf(stderr, "Error: Unrecognized argument\n");
      fprintf(stderr, "Usage: ./lab1a --port=portNum [--log=filename] [--compress]\n");
      exit(1);
      
    default:
      printf("?? getopt returned character code 0%o ??\n", c);
    }
  }
  
  if (portno == -1) {
    error("No port number given");
  }
  if (portno < 1025) {
      error("portno must be at least 1025");
  }
    
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0) { error("opening socket failed"); }
  server =  gethostbyname("localhost");
  if (server == NULL) { error("localhost doesn't exist"); }
  memset((char *) &serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  memcpy((char *)&serv_addr.sin_addr.s_addr,
    (char *)server->h_addr,
    server->h_length);
  serv_addr.sin_port = htons(portno);
  if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0)
    error("failed to connect");
  
  pollfds[0].fd = 0; // keyboard/stdin
  pollfds[1].fd = sockfd; // socket
  pollfds[0].events = POLLIN | POLLHUP | POLLERR;
  pollfds[1].events = POLLIN | POLLHUP | POLLERR;

  set_mode();
  
  read_write();

  exit(0);
}
